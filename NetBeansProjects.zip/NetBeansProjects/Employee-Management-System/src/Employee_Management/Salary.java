package Employee_Management;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
public class Salary extends JFrame implements ActionListener
{
    Font f,f1;
    JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12;
    JTextField tf1,tf2,tf3,tf4,tf5,tf6,tf7;
    Choice c1,c2,c3;
    JButton bt1,bt2;
    JPanel p1,p2,p3;
    
    Salary()
    {
        super("Salary");
        setLocation(100,100);
        setSize(950,750);
        setResizable(false);
        
        f=new Font("Arial",Font.BOLD,18);
        f1=new Font("Arial",Font.BOLD,25);
        
        l1=new JLabel("Select Emplooyee ID");
        l2=new JLabel("Name");
        l3=new JLabel("Email");
        l4=new JLabel("HRA");
        l5=new JLabel("DA");
        l6=new JLabel("MID");
        l7=new JLabel("PF");
        l8=new JLabel("Basic Salary");
        l9=new JLabel("Select Month");
        l10=new JLabel("Select Year");
        l12=new JLabel("Employee Salary");
        
        l12.setHorizontalAlignment(JLabel.CENTER);
        
        c1=new Choice();
        
        try
        {
            ConnectionClass obj=new ConnectionClass();
            String q="select Eid from Employee";
            ResultSet rest=obj.stm.executeQuery(q);
            while(rest.next())
            {
                c1.add(rest.getString("Eid"));
            }
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
        
        c2=new Choice();
        c2.add("January");
        c2.add("February");
        c2.add("March");
        c2.add("April");
        c2.add("May");
        c2.add("June");
        c2.add("July");
        c2.add("August");
        c2.add("September");
        c2.add("October");
        c2.add("November");
        c2.add("December");
        
        c3=new Choice();
        c3.add("2015");
        c3.add("2016");
        c3.add("2017");
        c3.add("2018");
        c3.add("2019");
        c3.add("2020");
        c3.add("2021");
        c3.add("2022");
        c3.add("2023");
        c3.add("2024");
        
        l1.setFont(f);
        l2.setFont(f);
        l3.setFont(f);
        l4.setFont(f);
        l5.setFont(f);
        l6.setFont(f);
        l7.setFont(f);
        l8.setFont(f);
        l9.setFont(f);
        l10.setFont(f);
        l12.setFont(f1);
        
        c1.setFont(f);
        c2.setFont(f);
        c3.setFont(f);
        
        tf1=new JTextField();
        tf2=new JTextField();
        tf3=new JTextField();
        tf4=new JTextField();
        tf5=new JTextField();
        tf6=new JTextField();
        tf7=new JTextField();
        
        tf1.setFont(f);
        tf2.setFont(f);
        tf3.setFont(f);
        tf4.setFont(f);
        tf5.setFont(f);
        tf6.setFont(f);
        tf7.setFont(f);
        
        tf1.setEditable(false);
        tf2.setEditable(false);
        
        ImageIcon img=new ImageIcon(ClassLoader.getSystemResource("Employee_Management/Icon/update.png"));
        Image img1=img.getImage().getScaledInstance(400,675,Image.SCALE_DEFAULT);
        ImageIcon ic1=new ImageIcon(img1);
        l11= new JLabel(ic1);
        
        bt1= new JButton("Submit");
        bt2= new JButton("Close");
        
        bt1.setFont(f);
        bt2.setFont(f);
        
        bt1.setBackground(Color.BLACK);
        bt1.setForeground(Color.WHITE);
        
        bt2.setBackground(Color.BLACK);
        bt2.setForeground(Color.WHITE);
        
        bt1.addActionListener(this);
        bt2.addActionListener(this);
        
        p1=new JPanel();
        p1.setLayout(new GridLayout(11,2,10,10));
        p1.add(l1);
        p1.add(c1);
        p1.add(l2);
        p1.add(tf1);
        p1.add(l3);
        p1.add(tf2);
        p1.add(l4);
        p1.add(tf3);
        p1.add(l5);
        p1.add(tf4);
        p1.add(l6);
        p1.add(tf5);
        p1.add(l7);
        p1.add(tf6);
        p1.add(l8);
        p1.add(tf7);
        p1.add(l9);
        p1.add(c2);
        p1.add(l10);
        p1.add(c3);
        p1.add(bt1);
        p1.add(bt2);
        
        p2=new JPanel();
        p2.setLayout(new GridLayout(1,1,10,10));
        p2.add(l11);
        
        p3=new JPanel();
        p3.setLayout(new GridLayout(1,1,10,10));
        p3.add(l12);
        
        setLayout(new BorderLayout(30,30));
        
        add(p1,"Center");
        add(p2,"West");
        add(p3,"North");
        
        c1.addMouseListener(new MouseAdapter()
        {
            @Override
            public void mouseClicked(MouseEvent arg0)
            {
                try
                {
                    ConnectionClass obj2=new ConnectionClass();
                    String eid2=c1.getSelectedItem();
                    String q3="select * from employee where Eid='"+eid2+"'";
                    ResultSet rest1=obj2.stm.executeQuery(q3);
                    while(rest1.next())
                    {
                        tf1.setText(rest1.getString("name"));
                        tf2.setText(rest1.getString("email"));
                    }
                }
                catch(Exception exx)
                {
                    exx.printStackTrace();
                }
            }
        });
    }
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource()==bt1)
        {
            String Eid=c1.getSelectedItem();
            String name=tf1.getText();
            String email=tf2.getText();
            float hra=Float.parseFloat(tf3.getText());
            float da=Float.parseFloat(tf4.getText());
            float mid=Float.parseFloat(tf5.getText());
            float pf=Float.parseFloat(tf6.getText());
            float basic=Float.parseFloat(tf7.getText());
            String month=c2.getSelectedItem()+" "+c3.getSelectedItem();
            
            try
            {
                ConnectionClass obj1=new ConnectionClass();
                String q1="insert into salary values('"+0+"','"+Eid+"','"+name+"','"+email+"','"+hra+"','"+da+"','"+mid+"','"+pf+"','"+basic+"','"+month+"')";
                int aa=obj1.stm.executeUpdate(q1);
                if(aa==1)
                {
                    JOptionPane.showMessageDialog(null,"Your Data Successfully Inserted");
                    this.setVisible(false);
                }
                else
                {
                    JOptionPane.showMessageDialog(null,"Please!, Fill All Details Carefully");
                    this.setVisible(false);
                    this.setVisible(true);
                }
            }
            catch(Exception ee)
            {
                ee.printStackTrace();
            }
        }
        if(e.getSource()==bt2)
        {
            JOptionPane.showMessageDialog(null,"Are you sure?");
            setVisible(false);
        }
    }
    public static void main(String args[])
    {
        new Salary().setVisible(true);
    }
}